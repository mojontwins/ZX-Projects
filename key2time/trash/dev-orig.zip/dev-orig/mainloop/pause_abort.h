			if (sp_KeyPressed (key_h)) {
				sp_WaitForNoKey ();
				_AY_ST_ALL ();
				_AY_PL_SND (8);
				//hide_sprites (0);
				//pause_screen ();
				while (sp_KeyPressed (key_h) == 0);
				sp_WaitForNoKey ();
				//draw_scr_background ();
				//run_entering_script ();
				// Play music
				//_AY_PL_MUS (level_data->music_id);
			}
			if (sp_KeyPressed (key_y)) {
				playing = 0;
			}
