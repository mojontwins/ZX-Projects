			
			if (p_killme) {
				p_state = EST_PARP;
				sp_UpdateNow ();
				//wyz_play_sample (0);
				active_sleep (50);
#ifdef PLAYER_HAS_SWIM
				if (p_engine != SENG_SWIM) {
#endif
					if (n_pant != p_safe_pant) {
						o_pant = n_pant = p_safe_pant;
						draw_scr ();
					}
					p_x = p_safe_x << FIXBITS;
					p_y = p_safe_y << FIXBITS;
					p_vx = 0;
					p_vy = 0;
					p_jmp_on = 0;
#ifdef PLAYER_HAS_SWIM
				}
#endif

				p_killme = 0;
				// Play music
				//_AY_PL_MUS (level_data->music_id);
				_AY_PL_SND (18);
			}
