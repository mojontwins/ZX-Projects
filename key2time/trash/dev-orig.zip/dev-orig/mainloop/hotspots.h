// MY FRIEND, YOU HAVE TO RECODE/REHASH/REWHATEVER THIS ASAP!
// This hasn't changed much since Churrera 1.0, for god's sake...

			// Hotspot interaction.
			if (collide (prx, pry, hotspot_x, hotspot_y)) {
				// Deactivate hotspot
				draw_coloured_tile (VIEWPORT_X + (hotspot_x >> 3), VIEWPORT_Y + (hotspot_y >> 3), orig_tile);
				gpit = 0;
				// Was it an object, key or life boost?
				if (hotspots [n_pant].act == 0) {
					p_life += PLAYER_REFILL;
					if (p_life > PLAYER_LIFE)
						p_life = PLAYER_LIFE;
					hotspots [n_pant].act = 2;
					_AY_PL_SND (3);
				} else {
					switch (hotspots [n_pant].tipo) {
#ifdef MAX_AMMO
						case 4:
							if (MAX_AMMO - p_ammo > AMMO_REFILL)
								p_ammo += AMMO_REFILL;
							else
								p_ammo = MAX_AMMO;
							_AY_PL_SND (3);
							break;
#endif

						case 5:
							if (99 - ctimer.t > TIMER_REFILL)
								ctimer.t += TIMER_REFILL;
							else
								ctimer.t = 99;
							_AY_PL_SND (3);
							break;

					}
					hotspots [n_pant].act = gpit;
				}
				hotspot_y = 240;
			}
