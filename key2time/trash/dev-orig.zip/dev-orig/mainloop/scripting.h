			gpit = (joyfunc) (&keys);

				if ((gpit & sp_FIRE) == 0) {
					if (action_pressed == 0)  {
						action_pressed = 1;
						// Any scripts to run in this screen?
						run_fire_script ();
					}
				} else {
					action_pressed = 0;
				}

				if (f_zone_ac) {
					if (prx >= fzx1 && prx <= fzx2 && pry >= fzy1 && pry <= fzy2) {
						run_fire_script ();
					}
				}
			