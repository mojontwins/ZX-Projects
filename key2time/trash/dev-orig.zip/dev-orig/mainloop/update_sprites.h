			for (gpit = 0; gpit < 3; ++ gpit) {
				enoffsmasi = enoffs + gpit;
				gpen_x = baddies [enoffsmasi].x;
				gpen_y = baddies [enoffsmasi].y;

				if ((baddies [enoffsmasi].t & 0x78) == 8) gpen_y -= PIXEL_SHIFT;
				
				sp_MoveSprAbs (
					sp_moviles [gpit], 
					spritesClip, 
					en_an_n_f [gpit] - en_an_c_f [gpit], 
					VIEWPORT_Y + (gpen_y >> 3), VIEWPORT_X + (gpen_x >> 3),
					gpen_x & 7, gpen_y & 7
				);
				
				en_an_c_f [gpit] = en_an_n_f [gpit];
			}

			if (0 == p_killme && ( !(p_state & EST_PARP) || half_life == 0) ) {
				gpz = pry - ((-p_z) >> FIXBITS);

				sp_MoveSprAbs (
					sp_shadow, 
					spritesClip, 
					0, 
					VIEWPORT_Y + (pry >> 3) + 1, VIEWPORT_X + (prx >> 3), 
					prx & 7, pry & 7
				);

				sp_MoveSprAbs (
					sp_player, 
					spritesClip, 
					p_n_f - p_c_f, 
					VIEWPORT_Y + (gpz >> 3), VIEWPORT_X + (prx >> 3), 
					prx & 7, gpz & 7
				);
			} else {
				sp_MoveSprAbs (
					sp_shadow, 
					spritesClip, 
					0, 
					-2, -2, 
					0, 0
				);

				sp_MoveSprAbs (
					sp_player, 
					spritesClip, 
					p_n_f - p_c_f, 
					-2, -2, 
					0, 0
				);
			}
			p_c_f = p_n_f;

			if (hitter_on) {
				sp_MoveSprAbs (sp_hitter, spritesClip,
					hitter_n_f - hitter_c_f,
					VIEWPORT_Y + (hitter_y >> 3), VIEWPORT_X + (hitter_x >> 3),
					hitter_x & 7, hitter_y & 7);
					hitter_c_f = hitter_n_f;
			} else {
				sp_MoveSprAbs (sp_hitter, spritesClip, 0, -2, -2, 0, 0);
			}

