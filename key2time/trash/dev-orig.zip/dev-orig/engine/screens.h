// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// Fixed screens

void screen_level (void) {
	blackout_area ();
	prx = 12; pry = 10; gpt = 71; k2t_show_time_prx_pry ();
	print_str (18, 10, 70, "AD");	
	
	/*
	if (level > 0) {
		gen_password ();
		print_str (12, 14, 71, password_text);
	}
	*/
	
	sp_UpdateNow ();

	//_AY_PL_MUS (5);				
	active_sleep (250);
}
