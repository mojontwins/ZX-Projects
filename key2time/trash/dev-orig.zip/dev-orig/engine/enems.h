// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// enems.h

#include "engine/enemmods/helper_funcs.h"
#include "engine/enemmods/kill_enemy.h"

void enems_move (void) {

	p_gotten = 0;
	ptgmx = ptgmy = 0;
	tocado = 0;

	for (gpit = 0; gpit < 3; gpit ++) {
		active = killable = animate = 0;
		enoffsmasi = enoffs + gpit;

		// Copy array values to temporary variables as fast as possible
		
		#asm
			// Those values are stores in this order:
			// x, y, x1, y1, x2, y2, mx, my, t, life
			// Point HL to baddies [enoffsmasi]. The struct is 10 bytes long
			// so this is baddies + enoffsmasi*9, or...
			// enoffsmasi is, at maximum, ((MAP_W*MAP_H)-1)*3+2, or 47.
			// We can keep the multiplications 8-bit as long as possible
			ld 	a, (_enoffsmasi) 	// Max 47
			sla a 					// Max 94  (x2)
			ld  b, a 				// B = A*2
			sla a 					// Max 188 (x4)
			ld  l, a
			ld  h, 0
			add hl, hl 				// HL = x8
			
			ld  e, b 
			ld  d, 0                // DE = x2
			add hl, de 				// HL = x10

			ld  de, _baddies
			add hl, de

			ld  (_gp_gen), hl 		// Save address for later

			ld  a, (hl)
			ld  (__en_x), a
			inc hl 

			ld  a, (hl)
			ld  (__en_y), a
			inc hl 

			ld  a, (hl)
			ld  (__en_x1), a
			inc hl 

			ld  a, (hl)
			ld  (__en_y1), a
			inc hl 

			ld  a, (hl)
			ld  (__en_x2), a
			inc hl 

			ld  a, (hl)
			ld  (__en_y2), a
			inc hl 

			ld  a, (hl)
			ld  (__en_mx), a
			inc hl 

			ld  a, (hl)
			ld  (__en_my), a
			inc hl 

			ld  a, (hl)
			ld  (__en_t), a
			inc hl 

			ld  a, (hl)
			ld  (__en_life), a
		#endasm
	
		if (en_an_state [gpit] == GENERAL_DYING) {
			en_an_count [gpit] --;
			if (0 == en_an_count [gpit]) {
				en_an_state [gpit] = 0;
				en_an_n_f [gpit] = sprite_18_a;
				goto continue_enems_loop;
			}
		}

		// Gotten preliminary:	
		pregotten =	(prx + 12 >= _en_x && prx <= _en_x + 12) &&
					(pry + 15 >= _en_y && pry <= _en_y);

		enemy_shoots = (_en_t & 4);
		gpt = _en_t >> 3;

		switch (gpt) {
			case 1:			// linear
				killable = 1;
			case 8:			// moving platforms
				#include "engine/enemmods/move_linear.h"
				break;
			#ifdef ENABLE_FLYING_ENEMIES
				case 2:		// flying
					#include "engine/enemmods/move_fanty.h"
					break;
			#endif
			#ifdef ENABLE_PURSUERS
				case 3:		// pursuers
					#include "engine/enemmods/move_pursuers.h"
					break;
			#endif
			case 10:		// arrows
				#include "addons/arrows/move.h"
				break;
			#ifdef ENABLE_HANNA_MONSTERS_11
				case 11:	// Hanna monsters type 11
					#include "engine/enemmods/move_hanna_11.h"
					break;
			#endif
			default:
				if (gpt > 15 && en_an_state [gpit] != GENERAL_DYING) en_an_n_f [gpit] = sprite_18_a;
		}

		if (active) {
			if (animate) {
				#include "engine/enemmods/animate.h"
			}

			// Carriable box launched and hit...
			#if defined (ENABLE_FO_CARRIABLE_BOXES) && defined (CARRIABLE_BOXES_THROWABLE)
				#include "engine/enemmods/throwable.h"
			#endif

			#include "engine/enemmods/hitter.h"

			#if defined (PLAYER_SIMPLE_BOMBS)
				#include "engine/enemmods/bombs.h"
			#endif

			// Collide with player
			#include "engine/enemmods/platforms_25d.h"
			if ((tocado == 0) && collide (prx, pry, gpen_cx, gpen_cy) && p_state == EST_NORMAL) {
				if (p_life > 0) {
					tocado = 1;
					kill_player (13);
					#ifdef TYPE_6_KILL_ON_TOUCH
						if (gpt == 2) {
							en_an_n_f [gpit] = sprite_18_a;
							_en_t |= 128;
						}
					#endif
				}
			}
			#asm
				._enems_collision_skip
			#endasm

			#ifdef PLAYER_CAN_FIRE
				#include "engine\enemmods\bullets.h"
			#endif
		}

		// Restore temporary values to arrays as fast as possible
	continue_enems_loop:
		#asm
		._continue_enems_loop_a
			// Those values are stores in this order:
			// x, y, x1, y1, x2, y2, mx, my, t, life

			ld  hl, (_gp_gen) 		// Restore pointer

			ld  a, (__en_x)
			ld  (hl), a
			inc hl

			ld  a, (__en_y)
			ld  (hl), a
			inc hl

			ld  a, (__en_x1)
			ld  (hl), a
			inc hl

			ld  a, (__en_y1)
			ld  (hl), a
			inc hl

			ld  a, (__en_x2)
			ld  (hl), a
			inc hl

			ld  a, (__en_y2)
			ld  (hl), a
			inc hl

			ld  a, (__en_mx)
			ld  (hl), a
			inc hl

			ld  a, (__en_my)
			ld  (hl), a
			inc hl

			ld  a, (__en_t)
			ld  (hl), a
			inc hl

			ld  a, (__en_life)
			ld  (hl), a
		#endasm
	}
}
