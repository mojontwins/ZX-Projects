// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// enems.h
// Enemy initialization (when entering a new screen), new style!

// Enemies' "t" is now slightly more complex:
// XTTTTDNN where
// X = dead
// TTTT = type       1000 = platform
//                   0001 = linear
//                   0010 = flying
//                   0011 = pursuing

// Reserved (addons)
//                   1001 = drops
//                   1010 = arrows
//                   1011 = Hanna Type 11
//                   1100 = Hanna Punchos


	for (gpit = 0; gpit < 3; gpit ++) {
		en_an_frame [gpit] = 0;
		en_an_count [gpit] = 3;
		en_an_state [gpit] = 0;
		enoffsmasi = enoffs + gpit;

		// Back to life!
		if (do_respawn) {
			baddies [enoffsmasi].t &= 0x7f;
			en_an_state [gpit] = 0;
#if defined (PLAYER_CAN_FIRE) || defined (PLAYER_CAN_PUNCH) || defined (PLAYER_HAZ_SWORD)
			baddies [enoffsmasi].life = level_data.enems_life;
#endif
		}

		// Init enems:
		// - Asign "base frame"
		// - Init coordinates for flying people
		// Remember XTTTTDNN, TTTT = type, D = fires balls, NN = sprite number

		gpt = baddies [enoffsmasi].t >> 3;
		if (gpt && gpt < 16) {
			en_an_base_frame [gpit] = (baddies [enoffsmasi].t & 3) << 1;

			switch (gpt) {
#ifdef ENABLE_FLYING_ENEMIES
				case 2:
					// Flying
#ifdef TYPE_6_FIXED_SPRITE
					en_an_base_frame [gpit] = TYPE_6_FIXED_SPRITE << 1;
#endif
					en_an_x [gpit] = baddies [enoffsmasi].x << FIXBITS;
					en_an_y [gpit] = baddies [enoffsmasi].y << FIXBITS;
					en_an_vx [gpit] = en_an_vy [gpit] = 0;
					en_an_state [gpit] = TYPE_6_IDLE;
					break;
#endif
#ifdef ENABLE_HANNA_MONSTERS_11
				case 11:
					en_an_state [gpit] = 0;
					break;
#endif
				default:
					break;
			}

		} else {
			en_an_n_f [gpit] = sprite_18_a;
		}
	}
