// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// initplayer.h
// Player initialization

void init_player (void) {
	// Inicializa player con los valores iniciales
	// (de ah� lo de inicializar).

	p_z = p_vz = 0;
	p_jmp_facing = 0;
#ifdef HANNA_ENGINE
	p_v = HANNA_WALK;
#endif
	p_vy = 0;
	p_vx = 0;
	p_jmp_ct = 1;
	p_jmp_on = 0;
	p_frame = 0;
	p_subframe = 0;
	p_facing = FACING_DOWN;
	p_facing_v = p_facing_h = 0xff;
	p_state = EST_NORMAL;
	p_state_ct = 0;
	p_objs = 0;
	p_keys = 0;
	flags [BODY_COUNT_ON] = 0;
	p_disparando = 0;
#ifdef MAX_AMMO
#ifdef INITIAL_AMMO
	p_ammo = INITIAL_AMMO;
#else
	p_ammo = MAX_AMMO;
#endif
#endif
	ctimer.count = 0;
	ctimer.zero = 0;
	ctimer.frames = TIMER_LAPSE;
	ctimer.t = TIMER_INITIAL;
	ctimer.on = 0;
	p_killme = 0;
	p_safe_pant = n_pant;
	p_safe_x = p_x >> (4+FIXBITS);
	p_safe_y = p_y >> (4+FIXBITS);
#if defined (BREAKABLE_WALLS) || defined (BREAKABLE_WALLS_SIMPLE)
#ifdef BREAKABLE_ANIM
	breaking_idx = 0;	
#endif	
#endif
#ifdef PLAYER_VARIABLE_JUMP
	PLAYER_JMP_VY_MAX = PLAYER_JMP_VY_MAX;
#endif
}
