// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// messages.h
// Misc. messages


void game_ending (void) {
	sp_UpdateNow();
	//blackout ();
	// Resource 2 = ending
	get_resource (2, 16384);
}

void game_over (void) {
	print_message (" GAME OVER! ");
	
}


