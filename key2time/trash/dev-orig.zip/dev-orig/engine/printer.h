// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// printer.h
// Printing functions

#define MESSAGE_COLOUR 79
unsigned char *spacer = "            ";

unsigned char attr (char x, char y) {
	// x + 15 * y = x + (16 - 1) * y = x + 16 * y - y = x + (y << 4) - y.
	if (x < 0 || y < 0 || x > 14 || y > 9) return 0;
	return map_attr [x + (y << 4) - y];
}

unsigned char qtile (unsigned char x, unsigned char y) {
	// x + 15 * y = x + (16 - 1) * y = x + 16 * y - y = x + (y << 4) - y.
	return map_buff [x + (y << 4) - y];
}

// Draw packed tile

void draw_coloured_tile (unsigned char x, unsigned char y, unsigned char t) {	
	t = 64 + (t << 2);
	gen_pt = tileset + 2048 + t;
	sp_PrintAtInv (y, x, *gen_pt ++, t ++);
	sp_PrintAtInv (y, x + 1, *gen_pt ++, t ++);
	sp_PrintAtInv (y + 1, x, *gen_pt ++, t ++);
	sp_PrintAtInv (y + 1, x + 1, *gen_pt, t);
}

void draw_coloured_tile_gamearea (unsigned char x, unsigned char y, unsigned char tn) {
	draw_coloured_tile (VIEWPORT_X + (x << 1), VIEWPORT_Y + (y << 1), tn);
}

void print_number2 (unsigned char x, unsigned char y, unsigned char number) {
	sp_PrintAtInv (y, x, 7, 16 + (number / 10));
	sp_PrintAtInv (y, x + 1, 7, 16 + (number % 10));
}

void print_str (unsigned char x, unsigned char y, unsigned char c, unsigned char *s) {
	while (*s) sp_PrintAtInv (y, x ++, c, (*s ++) - 32);
}

void blackout_area (void) {
	// blackens gameplay area for LEVEL XX display
	asm_int [0] = 22528 + 32 * VIEWPORT_Y + VIEWPORT_X;
	#asm
		ld	hl, _asm_int
		ld	a, (hl)
		ld	e, a
		inc	hl
		ld	a, (hl)
		ld	d, a

		ld b, 20
	.bal1
		push bc
		push de
		pop hl
		ld	(hl), 0
		inc de
		ld bc, 29
		ldir
		inc de
		inc de
		pop bc
		djnz bal1
	#endasm
}

unsigned char utaux = 0;
void update_tile (unsigned char x, unsigned char y, unsigned char b, unsigned char t) {
	utaux = (y << 4) - y + x;
	map_attr [utaux] = b;
	map_buff [utaux] = t;
	draw_coloured_tile_gamearea (x, y, t);
}

void print_message (unsigned char *s) {
	print_str (10, 11, MESSAGE_COLOUR, spacer);
	print_str (10, 12, MESSAGE_COLOUR, s);
	print_str (10, 13, MESSAGE_COLOUR, spacer);
	sp_UpdateNow ();
	sp_WaitForNoKey ();
}

unsigned char button_pressed (void) {
	return (sp_GetKey () || ((((joyfunc) (&keys)) & sp_FIRE) == 0));
}

void main_spr_frame (unsigned char x, unsigned char y) {
	sp_MoveSprAbs (sp_player, spritesClip, p_n_f - p_c_f, VIEWPORT_Y + (y >> 3), VIEWPORT_X + (x >> 3), x & 7, y & 7);
	p_c_f = p_n_f;
	sp_UpdateNow ();
}

// Subtileset loader
unsigned int offs_attr, offs_behs;
unsigned char load_subtileset (unsigned char res, unsigned char n) {
	// Get offsets
	offs_attr = read_offset (res, 0);
	offs_behs = read_offset (res, 2);

	// Unpack patterns
	unpack_RAMn (resources [res].ramPage, resources [res].ramOffset + 4, (unsigned int) (tileset + (n << 9) + 512));
	// Unpack attributes
	unpack_RAMn (resources [res].ramPage, resources [res].ramOffset + offs_attr, (unsigned int) (tileset + (n << 6) + 2112));
	// Unpack behs
	unpack_RAMn (resources [res].ramPage, resources [res].ramOffset + offs_behs, (unsigned int) (behs + (n << 4)));
}

void print_digitH (unsigned char x, unsigned char y, unsigned char d) {
	if (d < 10) sp_PrintAtInv (y, x, 7, d+16);
	else        sp_PrintAtInv (y, x, 7, d+23);
}

void print_numberH (unsigned char x, unsigned char y, unsigned char n) {
	print_digitH (x, y, n >> 4);
	print_digitH (x + 1, y, n & 15);
}
