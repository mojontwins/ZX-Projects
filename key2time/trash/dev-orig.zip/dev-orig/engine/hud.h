// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// hud.h
// Heads-up display (shows your life, keys, etc...)

unsigned char objs_old, keys_old, life_old, killed_old;
void update_hud (void) {
	if (p_life != life_old) {
		print_number2 (LIFE_X, LIFE_Y, p_life);
		life_old = p_life;
	}
}
