// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// drawscr.h
// Screen drawing functions


void draw_scr_background (void) {
	#asm
		ld	hl, (_n_pant)
		ld  h, 0
		ld	(rnd + 1),hl
		ld	hl, (_level)
		ld  h, 0
		ld	(rnd + 4),hl
	#endasm
	
	map_pointer = map + (n_pant << 6) + (n_pant << 3) + (n_pant << 1) + (n_pant);
	gpit = rdx = rdy = 0;

	// Draw 150 tiles
	do {
		gpjt = rand () & 15;

		if (gpit & 1) {
			rdd = rdc & 15;
		} else {
			rdc = *map_pointer ++;
			rdd = rdc >> 4;
		}

		map_attr [gpit] = behs [rdd];
		map_buff [gpit] = rdd;
		draw_coloured_tile_gamearea (rdx, rdy, rdd);

		++ rdx; if (rdx == 15) { rdx = 0; ++ rdy; }
	} while (++ gpit < 150);
}

void draw_scr (void) {
	if (cur_map_attr != map_attrs [n_pant]) {
		cur_map_attr = map_attrs [n_pant];
		if (cur_map_attr) load_subtileset (levels [level].resource + cur_map_attr, 1);
	}
	
	if (no_draw) no_draw = 0; else draw_scr_background ();
	
	f_zone_ac = 0;
	
	enoffs = (n_pant << 1) + n_pant;	

	do_respawn = 1;

	FO_clear ();
	run_entering_script ();

	x_pant = n_pant % level_data->map_w;
	y_pant = n_pant / level_data->map_w;

	p_safe_pant = n_pant;
	p_safe_x = (p_x >> FIXBITS);
	p_safe_y = (p_y >> FIXBITS);
}
