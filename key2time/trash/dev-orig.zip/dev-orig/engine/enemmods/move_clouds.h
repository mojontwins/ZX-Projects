	// Move Clouds

	active = 1;

	if (prx != _en_x) _en_x += addsign (prx - _en_x, _en_mx);

	// Shoot a coco
	if ((rand () & TYPE_9_SHOOT_FREQ) == 1) shoot_coco ();
			