	if (fo_fly && killable) {
		
		if (f_o_xp + 15 >= _en_x && f_o_xp <= _en_x + 15 &&
			f_o_yp + 15 >= _en_y && f_o_yp <= _en_y + 15) {
			en_an_n_f [gpit] = sprite_17_a;
			en_an_state [gpit] = GENERAL_DYING;
			en_an_count [gpit] = 8;
			#ifdef CARRIABLE_BOXES_COUNT_KILLS
				flags [CARRIABLE_BOXES_COUNT_KILLS] ++;
			#endif
			_en_t |= 128;
			flags [BODY_COUNT_ON] ++;

			run_script (2 * MAP_W * MAP_H + 5);
			goto continue_enems_loop;
		}
	}
