	/*
	if (hitter_on && killable && hitter_hit == 0) {
		if (hitter_frame < 5) {
			if (collide_pixel (hitter_x + (p_facing ? 14 : 1), hitter_y + 3, _en_x, _en_y)) {
				hitter_hit = 1;
				enemy_kill (PLAYER_HITTER_STRENGTH);
				goto continue_enems_loop;
			}
		}
	}
	*/

	#asm

			ld  a, (_hitter_on)
			and a
			jr  z, _enems_hitter_done

			ld  a, (_killable)
			and a
			jr  z, _enems_hitter_done

			ld  a, (_hitter_hit)
			and a
			jr  nz, _enems_hitter_done

			ld  a, (_hitter_frame)
			cp  5
			jr  nc, _enems_hitter_done

			// if (collide_pixel (hitter_x + (p_facing ? 14 : 1), hitter_y + 3, _en_x, _en_y))

			// Parameter 1
			ld  a, (_p_facing)
			and a
			jr  z, _enems_hitter_a_set_1

			ld  c, 14
			jr _enems_hitter_a

		._enems_hitter_a_set_1
			ld  c, 1

		._enems_hitter_a
			ld  a, (_hitter_x)
			add a, c

			ld  h, 0
			ld  l, a
			push hl

			// Parameter 2
			ld  hl, (_hitter_y)
			ld  h, 0
			inc hl
			inc hl
			inc hl
			push hl

			// Parameter 3
			ld  hl, (__en_x)
			ld  h, 0
			push hl

			// Parameter 4
			ld  hl, (__en_y)
			ld  h, 0
			push hl

			call _collide_pixel

			pop bc
			pop bc
			pop bc
			pop bc

			// Result is in HL
			ld  a, h 
			or  l
			jr  z, _enems_hitter_done


			// hitter_hit = 1;
			ld  a, 1
			ld  (_hitter_hit), a

			// enemy_kill (PLAYER_HITTER_STRENGTH);
			ld  hl, PLAYER_HITTER_STRENGTH
			push hl

			call _enemy_kill

			pop bc

			// goto continue_enems_loop;
			jp  _continue_enems_loop_a

		._enems_hitter_done
	#endasm