	// First, preliminary version. No real collision, just ground level.
	if (p_vz < PLAYER_FALL_VY_MAX) p_vz += PLAYER_G; else p_vz = PLAYER_FALL_VY_MAX;
