	if (!BUTTON_FIRE) {
		p_disparando = 0;
		invalidate_fire = 0;
	}
