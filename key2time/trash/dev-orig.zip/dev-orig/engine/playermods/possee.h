	// Very perliminar 2.5D
	pry = p_y >> FIXBITS;
	pty1 = (pry + 15) >> 4;
	ptx1 = (prx + 8) >> 4;
	possee = (p_z == 0) && (attr (ptx1, pty1) != 3);
