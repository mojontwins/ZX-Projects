	// Conveyors
	#include "engine/playermods/ha_conveyors.h"
	
	// Controller
	#include "engine/playermods/ha_controller.h"

	// Move
	p_x = p_x + p_vx;
	if (p_gotten) p_x += ptgmx;

	// Safe
	if (p_x < 0) p_x = 0;
	if (p_x > (224 << FIXBITS)) p_x = (224 << FIXBITS);

	prx = p_x >> FIXBITS;

	// Handle collision
	// "New genital" top-down games need slightly different vertical collision
	#include "engine/playermods/ha_collision_25d.h"
