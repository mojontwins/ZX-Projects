
	#include "engine/playermods/va_genital.h"

	// Gravity
	#include "engine/playermods/va_gravity.h"

	// Move
	p_y += p_vy;
	if (p_gotten) p_y += ptgmy;

	p_z += p_vz;
	if (p_z > 0) p_z = p_vz = 0;
	
	// Safe
	if (p_y < 0) p_y = 0;
	if (p_y > (144 << FIXBITS)) p_y = (144 << FIXBITS);

	pry = p_y >> FIXBITS;

	// Handle collision
	// "New genital" top-down games need slightly different vertical collision
	#include "engine/playermods/va_collision_25d.h"
	
	// Possee - player is on solid floor.
	#include "engine/playermods/possee.h"

	// Jumping Jack!
	#include "engine/playermods/jump_genital.h"
