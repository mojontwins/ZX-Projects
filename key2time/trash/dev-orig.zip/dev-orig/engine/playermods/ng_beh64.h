	p_ax = PLAYER_AX;
	p_rx = PLAYER_RX;
	if (pt1 & 64) {
		if (possee) {
			p_ax = PLAYER_AX_ALT;
			p_rx = PLAYER_RX_ALT;
		}
	}
	