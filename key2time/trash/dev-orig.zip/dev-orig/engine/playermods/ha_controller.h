	if ( ! ((gpit & sp_LEFT) == 0 || (gpit & sp_RIGHT) == 0) && p_z == 0) 
	{
		p_facing_h = 0xff;
		if (p_vx > 0) {
			p_vx -= RXVAL; if (p_vx < 0) p_vx = 0;
		} else if (p_vx < 0) {
			p_vx += RXVAL; if (p_vx > 0) p_vx = 0;
		}
	}

	if ((gpit & sp_LEFT) == 0) {
		p_thrust = 1;
		p_facing_h = FACING_LEFT;
		if (p_vx > -PLAYER_VX_MAX) {
			p_vx -= AXVAL;
		}
	}

	if ((gpit & sp_RIGHT) == 0) {
		p_thrust = 1;
		p_facing_h = FACING_RIGHT;
		if (p_vx < PLAYER_VX_MAX) {
			p_vx += AXVAL;
		}
	}
