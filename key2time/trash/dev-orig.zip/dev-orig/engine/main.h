// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// engine.h
// Well, self explanatory innit?

#define PLAYER_MIN_KILLABLE 0

// Animation frames
#include "engine/frames.h"

// Prepare level (compressed levels)
#include "engine/clevels.h"

// Init player
#include "engine/initplayer.h"

// Collision
#include "engine/collision.h"

// Messages
#include "engine/messages.h"

void step (void) {
	#asm
		ld a, 16
		out (254), a
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		xor 16
		out (254), a
	#endasm
}

void cortina (void) {
	#asm
		ld b, 7
	.fade_out_extern
		push bc

		ld   e, 3               ; 3 tercios
		ld   hl, 22528          ; aqu� empiezan los atributos
	#endasm
	#asm
		halt                    ; esperamos retrazo.
	#endasm
	#asm
	.fade_out_bucle
		ld   a, (hl )           ; nos traemos el atributo actual

		ld   d, a               ; tomar atributo
		and  7                  ; aislar la tinta
		jr   z, ink_done        ; si vale 0, no se decrementa
		dec  a                  ; decrementamos tinta
	.ink_done
		ld   b, a               ; en b tenemos ahora la tinta ya procesada.

		ld   a, d               ; tomar atributo
		and  56                 ; aislar el papel, sin modificar su posición en el byte
		jr   z, paper_done      ; si vale 0, no se decrementa
		sub  8                  ; decrementamos papel restando 8
	.paper_done
		ld   c, a               ; en c tenemos ahora el papel ya procesado.
		ld   a, d
		and  192                ; nos quedamos con bits 6 y 7 (BRIGHT y FLASH)
		or   c                  ; a�adimos paper
		or   b                  ; e ink, con lo que recompuesto el atributo
		ld   (hl),a             ; lo escribimos,
		inc  l                  ; e incrementamos el puntero.
		jr   nz, fade_out_bucle ; continuamos hasta acabar el tercio (cuando L valga 0)
		inc  h                  ; siguiente tercio
		dec  e
		jr   nz, fade_out_bucle ; repetir las 3 veces
		pop bc
		djnz fade_out_extern
	#endasm
}

signed int addsign (signed int n, signed int value) {
	//if (n >= 0) return value; else return -value;
	return n == 0 ? 0 : n > 0 ? value : -value;
}

unsigned int abs (int n) {
	if (n < 0)
		return (unsigned int) (-n);
	else
		return (unsigned int) n;
}

void kill_player (unsigned char sound) {
	p_life --;
	//_AY_ST_ALL ();
	_AY_PL_SND (sound);
	if (p_ct_hole >= 2)
	{
		p_killme = 1;
		half_life = 0;
	}
	p_state = EST_PARP;
	p_state_ct = 50;
}

// Floating objects
#include "engine/fo_genital.h"

// Animated tiles

// Breakable tiles helper functions
#ifdef BREAKABLE_WALLS
#include "engine/breakable.h"
#endif

#ifdef BREAKABLE_WALLS_SIMPLE
#include "engine/breakable-s.h"
#endif

// Hitter (punch/sword) helper functions
#include "engine/hitter.h"

// Bullets helper functions
#ifdef PLAYER_CAN_FIRE
#include "engine/bullets.h"
#endif

// Simple bomb helper functions
#ifdef PLAYER_SIMPLE_BOMBS
#include "engine/bombs-s.h"
#endif

// Main player movement
#if defined (PHANTOMAS_ENGINE)
#include "engine/phantomasmove.h"
#else
#include "engine/playermove.h"
#endif

void run_entering_script (void) {
		// Ejecutamos los scripts de entrar en pantalla:
		run_script (2 * MAP_W * MAP_H + 1);
		run_script (n_pant + n_pant);
}

// Screen drawing
#include "engine/drawscr.h"

// Enemies
#include "engine/enems.h"

void active_sleep (int espera) {
	do {
		#asm
			halt
		#endasm
		if (p_killme == 0 && button_pressed ()) break;
	} while (--espera);
	sp_Border (0);
}

void run_fire_script (void) {
	run_script (2 * MAP_W * MAP_H + 2);
	run_script (n_pant + n_pant + 1);
	// I use this for debug when further developing the engine, it comes handy:
	/*
		for (gpit = 0; gpit < 16; gpit ++) {
			sp_PrintAtInv (0, gpit + gpit, 71, 16 + flags [gpit]);
		}
	*/
	/*
		for (gpit = 0; gpit < 16; gpit ++) {
			//sp_PrintAtInv (23, gpit + gpit, 71, 16 + baddies [enoffs + gpit].t);
			print_number2(gpit+gpit,23,flags [gpit]);
		}
	*/
}

// Hud
#include "engine/hud.h"

