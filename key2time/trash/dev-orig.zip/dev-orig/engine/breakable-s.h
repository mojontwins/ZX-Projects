// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// breakable-s.h
// Simple breakable tiles helper functions

void wall_broken (unsigned char x, unsigned char y) {
	gpd = 0;
	gpaux = (y << 4) - y + x;
#ifdef BREAKABLE_TILE_GET
	if (map_buff [gpaux] == BREAKABLE_TILE_GET &&
		(rand () & BREAKABLE_TILE_FREQ) <= BREAKABLE_TILE_FREQ_T) gpd = TILE_GET;
#endif
	update_tile (x, y, 0, gpd);

	// Persistent maps:
}

#ifdef BREAKABLE_ANIM
void process_breakable () {
	unsigned char brkit;

	do_process_breakable = 0;

	for (brkit = 0; brkit < MAX_BREAKABLE; brkit ++) {
		if (breaking_f [brkit]) {
			if (! --breaking_f [brkit]) {
				_AY_PL_SND (17);
				wall_broken (breaking_x [brkit], breaking_y [brkit]);
			} else {
				do_process_breakable = 1;
			}
		}
	}
}
#endif

void break_wall (unsigned char x, unsigned char y) {
	if (attr (x, y) & 16) {
		gpaux = (y << 4) - y + x;
		map_attr [gpaux] &= 0xEF; // 11101111, remove "breakable" bit.
#ifdef BREAKABLE_ANIM
		// add this block to the "breaking" tile list
		breaking_f [breaking_idx] = MAX_BREAKABLE_FRAMES;
		breaking_x [breaking_idx] = x;
		breaking_y [breaking_idx] = y;
		draw_coloured_tile_gamearea (x, y, BREAKABLE_TILE);
		breaking_idx ++; if (breaking_idx == MAX_BREAKABLE) breaking_idx = 0;
		do_process_breakable = 1;
#else
		// break this block.
		wall_broken (x, y);
#endif
	
		_AY_PL_SND (14);
	}
}
