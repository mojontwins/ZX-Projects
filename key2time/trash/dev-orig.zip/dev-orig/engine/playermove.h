// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// playermove.h
// Player movement v5.0 : half-box/point collision
// Copyleft 2013 by The Mojon Twins

// Predefine button detection
#define BUTTON_FIRE	((gpit & sp_FIRE) == 0 || sp_KeyPressed (key_fire))
#define BUTTON_JUMP	(sp_KeyPressed (key_jump))

unsigned char player_move (void) {
	#asm
			xor a
			ld  (_wall_v), a
			ld  (_wall_h), a
			ld  (_p_thrust), a
	#endasm	
	gpit = (joyfunc) (&keys);

	// Get bottom-center pixel tile behaviour for several NEW_GENITAL stuff	
	// pt1 = attr ((prx + 8) >> 4, (pry + 15) >> 4);	
	#asm
			ld  h, 0
			
			ld  a, (_prx)
			add 8
			sra a
			sra a
			sra a
			sra a
			ld  l, a
			push hl

			ld  a, (_pry)
			add 15
			sra a
			sra a
			sra a
			sra a
			ld  l, a
			push hl

			call _attr

			pop bc
			pop bc

			ld  a, l
			ld  (_pt1), a
	#endasm

	// Pre-detect conveyors. Needs attr @ bottom-center pixel in pt1!
	#include "engine/playermods/ng_conveyors.h"

	// Pre-detect behaviour 64. Needs attr @ bottom-center pixel in pt1!
	#include "engine/playermods/ng_beh64.h"
	// ***************************************************************************
	//  MOVEMENT IN THE VERTICAL AXIS
	// ***************************************************************************

	#include "engine/playermods/va.h"

	// ***************************************************************************
	//  MOVEMENT IN THE HORIZONTAL AXIS
	// ***************************************************************************

	#include "engine/playermods/ha.h"

	// **********
	// MORE STUFF
	// **********

	// Priority to decide facing
	/*
	if (p_facing_h != 0xff) {
		p_facing = p_facing_h;
	} else if (p_facing_v != 0xff) {
		p_facing = p_facing_v;
	}
	*/

	#asm
			ld  a, (_p_facing_h)
			cp  255
			jr  nz, player_moving_facing_set 
		
		.player_moving_facing_sel_not_h
			ld  a, (_p_facing_v)
			cp  255
			jr  z, player_moving_facing_done		

		.player_moving_facing_set
			ld  (_p_facing), a

		.player_moving_facing_done

	#endasm

	// *******
	// Hitters
	// *******
	
	#include "engine/playermods/hitter.h"

	// *****
	// Bombs
	// *****
	
	#include "engine/playermods/bombs.h"

	// Done with the fire button...

	if (0 == BUTTON_FIRE) p_disparando = invalidate_fire = 0;

	// **********
	// Evil tiles
	// **********

	// hit_v tiene preferencia sobre hit_h
	hit = 0;
	if (hit_v == TILE_EVIL) {
		hit = 1;
		p_vy = addsign (-p_vy, PLAYER_VX_MAX);
	} else if (hit_h == TILE_EVIL) {
		hit = 1;
		p_vx = addsign (-p_vx, PLAYER_VX_MAX);
	}
	if (hit) {
		if (p_life > 0 && p_state == EST_NORMAL) {
			kill_player (8);
		}
	}

	// **********
	// Hole tiles
	// **********

	prx = p_x >> FIXBITS;
	pty1 = (pry + 15) >> 4;
	ptx1 = (prx + 4) >> 4;
	ptx2 = (prx + 12) >> 4;
	if (p_z == 0 && p_gotten == 0 && attr (ptx1, pty1) == 3 && attr (ptx2, pty1) == 3 && p_state == EST_NORMAL) {
		if (p_ct_hole < 2) {
			p_ct_hole ++;
		} else {
			if (p_vy > 0) pry += 8;
			p_n_f = FALLING_FRAME;
			main_spr_frame (prx, pry);
			active_sleep (25);
			p_n_f = FALLING_FRAME + 144;
			main_spr_frame (prx, pry);
			active_sleep (25);
			kill_player (0);
		}
	} else p_ct_hole = 0;

	// ********
	// Tile get 
	// ********
	

	// **********************
	// Select animation frame
	// **********************

	#asm
		// if (p_z != 0) { p_n_f = player_frames [1 + p_jmp_facing]; } else

			ld  a, (_p_z)
			and a
			jr  z, _player_move_af_floor

			ld  de, (_p_jmp_facing)
			ld  d, 0
			inc de
			ld  hl, _player_frames
			add hl, de
			add hl, de
			jr  _player_move_af_done

		._player_move_af_floor

			// if (p_vx == 0 && p_vy == 0) { p_n_f = player_frames [p_facing]; } else

			ld  a, (_p_vx)
			and a
			jr  nz, _player_move_af_floor_moving

			ld  a, (_p_vy)
			and a
			jr  nz, _player_move_af_floor_moving

			ld  de, (_p_facing)
			ld  d, 0
			ld  hl, _player_frames
			add hl, de
			add hl, de
			jr  _player_move_af_done

		._player_move_af_floor_moving

			ld  a, (_p_subframe)
			inc a
			ld  (_p_subframe), a
			cp  4
			jr  nz, _player_move_af_incframe_done

			ld  a, (_p_frame)
			xor 1
			ld  (_p_frame), a

			call _step

			xor a			
		._player_move_af_incframe_done
			ld  (_p_subframe), a

			ld  a, (_p_facing)
			ld  c, a
			ld  a, (_p_frame)
			add c
			sla a
			ld  b, 0
			ld  c, a
			ld  hl, _player_frames
			add hl, bc
			jr  _player_move_af_done

		._player_move_af_done
			ld  de, _p_n_f
			ldi
			ldi
			
	#endasm
}
