// MT Engine MK2 v0.88
// Copyleft 2014 the Mojon Twins

#define FIXBITS 4

#include <spritepack.h>

#pragma output STACKPTR=24199
#define FREEPOOL 	61697
#define NUMBLOCKS	54
unsigned char dynamic_memory_pool [NUMBLOCKS * 15];

#include "config.h"

// Cosas del juego:

#include "definitions.h"
#include "globals.h"
#include "autodefs.h"
#include "my/msc-config.h"
#include "system/128k.h"
#include "system/aplib.h"
#include "librarian.h"
#include "levels128.h"
#include "addons/helpers.h"
#include "addons/arrows/sprites.h"
#include "sound/nosoundplayer.h"
#include "engine/printer.h"
#include "my/extern_e.h"
#include "my/msc.h"
#include "engine/screens.h"
#include "engine/random.h"
#include "engine/main.h"
#include "engine/flickscreen.h"
#include "mainloop/hide_sprites.h"
#include "mainloop.h"
