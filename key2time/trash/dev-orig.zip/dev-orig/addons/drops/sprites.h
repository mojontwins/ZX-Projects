// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// drops/sprites.h
// Frame 0: falling drop, frames 1-3: exploding drop.

extern unsigned char drop_sprites [0];
#asm
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
._drop_sprites
	BINARY "spdrop.bin"
#endasm
