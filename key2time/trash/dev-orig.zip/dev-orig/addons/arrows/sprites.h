// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// arros/sprites.h
// Frame 0: arrow left. Frame 1: arrow right

extern unsigned char arrow_sprites [0];
#asm
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
	defb 0, 255
._arrow_sprites
	BINARY "..\bin\sparrow.bin"
#endasm
