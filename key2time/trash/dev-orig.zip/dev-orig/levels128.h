// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// levels128.h
// Level definition for 128k games

// This is the level manager used in Ninjajar!

// This can be considered completely custom but also can be reused/refined.
// I will probably come with something more simple for future games.

// Right away, the levelset is containted in two structures, the
// levels [] array, which has an entry for each unique level, and the
// level_sequence [] array, which defines an order for the levels
// (in case you want to reuse a level - like we do in Ninjajar!)

// Definitions
// This is fixed. 32 bolts per level.
#define MAX_bolts 32

// Types:
// This contains the level data for current level. Not really needed, but
// this is here because of legacy support of 128K full-contained levels like
// those found in Goku Mal.
typedef struct {
	unsigned char map_w, map_h;
	unsigned char scr_ini, ini_x, ini_y;
	unsigned char max_objs;
	unsigned char enems_life;
	unsigned char win_condition;
	unsigned char scr_fin;
	unsigned char activate_scripting;
	unsigned char music_id;
	unsigned char d05;
	unsigned char d06;
	unsigned char d07;
	unsigned char d08;
	unsigned char d09;
} LEVELHEADER;

typedef struct {
    unsigned char np, x, y, st;
} BOLTS;

typedef struct {
	unsigned char x, y;
	unsigned char x1, y1, x2, y2;
	char mx, my;
	unsigned char t, life;
} BADDIE;

typedef struct {
	unsigned char resource;
	unsigned char music_id;
	unsigned int script_offset;
} LEVEL;

// Space reserved for levels
// This will be overwritten with the unpacked data

// Esta forma mierder-rara de hacerlo es porque z88dk no se aclara... O no me aclaro yo.
extern LEVELHEADER level_data [0];
extern unsigned char map [0];
extern unsigned char map_attrs [0];
extern unsigned char tileset [0];
extern unsigned char spriteset [0];
extern unsigned char sprite_e [0];
extern BADDIE baddies [0];
extern unsigned char behs [0];

#asm
	._level_data 
		defs 16
	._map 
		defs MAP_W * MAP_H * 75
	._map_attrs 
		defs MAP_W * MAP_H
	._tileset 
		BINARY "..\bin\basicts.bin"
#endasm
#include "sprites-empty.h"
#asm
	._sprite_e 
		defs 144 * EXTRA_SPRITES
	._baddies 
		defs MAP_W * MAP_H * 3 * 10
	._behs 
		defs 48
#endasm

// This is different - we take extrasprites.h from the main chunk
// so we can use level bundles without having to worry.
#include "extrasprites.h"

// Level struct
LEVEL levels [] = {
	{LEVEL0C_BIN, 0, SCRIPT_INIT + LEVEL_0},
	{0, 0, 0},
	{LEVEL2C_BIN, 2, SCRIPT_INIT + LEVEL_2},
	{0, 0, 0},
	{0, 0, 0},
	{LEVEL5C_BIN, 5, SCRIPT_INIT + LEVEL_5},
	{LEVEL6C_BIN, 6, SCRIPT_INIT + LEVEL_6},
	{0, 0, 0},
	{0, 0, 0},
	{LEVELTC_BIN, 9, SCRIPT_INIT + LEVEL_TARDIS}
};
