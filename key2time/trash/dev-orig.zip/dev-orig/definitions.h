// Key To Time Engine v0.1
// Copyleft 2015, 2019 the Mojon Twins

// definitions.h
// Main definitions

// General defines

#define EST_NORMAL 		0
#define EST_PARP 		2
#define EST_MUR 		4
#define sgni(n)			(n < 0 ? -1 : 1)
#define saturate(n)		(n < 0 ? 0 : n)
#define WTOP 1
#define WBOTTOM 2
#define WLEFT 3
#define WRIGHT 4

#define FACING_RIGHT 0
#define FACING_LEFT 2
#define FACING_UP 4
#define FACING_DOWN 6

#define SENG_JUMP 0
#define SENG_SWIM 1
#define SENG_COPT 2
#define SENG_JETP 3
#define SENG_BOOT 4

#define TYPE_6_IDLE 		0
#define TYPE_6_PURSUING		1
#define TYPE_6_RETREATING	2
#define GENERAL_DYING		4

#define MAX_FLAGS 128
#define BUFFER_IDX(x,y) x+(y<<4)-y

#define TILE_EVIL 1
#define TILE_HOLE 2

// Predefine button detection
#define BUTTON_FIRE	((gpit & sp_FIRE) == 0 || sp_KeyPressed (key_fire))
#define BUTTON_JUMP	(sp_KeyPressed (key_jump))
